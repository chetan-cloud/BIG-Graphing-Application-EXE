MAC-ONLY

Steps:

1. Download ZIP file and decompress
2. In the '_internal' folder, you can locate the xlsx (Excel) file called 'BIGSheet.xlsx'
3. When clicked, it should open an Excel document where there are further instructions on adding and removing data. There is also additional customization to the graph through this file.
4. After making the necessary changes, you should exit the '_internal' folder into the larger 'BIG' folder. In that folder, there should be an executable (exe) called 'BiG'.
5. Once located, control-click the file, there will then be a pop-up asking you to open the file. Click open on that pop-up.
6. From there, the program will open a terminal (window), and after 30 seconds it will display a graph that you can view.
7. The graph can be saved, adjusted, and other operations.
